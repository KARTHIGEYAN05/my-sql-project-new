import { Firedetection } from './firedetection.model';

describe('Firedetection', () => {
  it('should create an instance', () => {
    expect(new Firedetection()).toBeTruthy();
  });
});
