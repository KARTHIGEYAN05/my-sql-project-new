export class Firedetection {
}
